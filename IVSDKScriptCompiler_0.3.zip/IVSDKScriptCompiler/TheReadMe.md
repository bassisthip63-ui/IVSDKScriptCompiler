# IVSDKScriptCompiler 0.3 (experimental)

**Run ScriptHookDotNet scripts from `.cs` / `.vb` source under IV-SDK .NET, the way ScriptHookDotNet 1.7.1.9 did.**

Some older mods ship as source code, for example `ChopShop.cs`. ScriptHookDotNet 1.7.1.9 ran those directly, but IV-SDK .NET only loads built `.net.dll` files, so those mods do nothing. IVSDKScriptCompiler fixes that. When the game starts, it compiles each source script into a `.net.dll`, and IV-SDK .NET loads it like any other ScriptHookDotNet mod.

Tested with IV-SDK .NET 1.9.1 on GTA IV Complete Edition 1.2.0.59. It doesn't depend on the game version.

Source code, full documentation and issues: <https://github.com/bassisthip63-ui/IVSDKScriptCompiler>

---

## What you need

- GTA IV or EFLC with **IV-SDK .NET 1.9.x**, with its **ScriptHookDotNet support** installed: `IVSDKDotNet\bin\ScriptHookDotNet.dll` must be present.
- **.NET Framework 4.x.** Every supported Windows version already has it.

## What's in this download

```
IVSDKScriptCompiler\
  TheReadMe.md                       this file
  LICENSE
  TheFiles\                          the mod
    IVSDKDotNet\scripts\IVSDKScriptCompiler.ivsdk.dll
  TheTestScript\                     optional test script
    scripts\HelloSource.net.cs
```

## Install

1. Copy the **`IVSDKDotNet`** folder from **`TheFiles`** into your GTA IV folder (the one with `GTAIV.exe`), and let it merge with the `IVSDKDotNet` folder that's already there. The mod ends up here:
   ```
   GTA IV\
     GTAIV.exe
     IVSDKDotNet\
       scripts\
         IVSDKScriptCompiler.ivsdk.dll   <- here
   ```
2. Start the game once. The IV-SDK .NET console (F4) shows `IVSDKScriptCompiler 0.3: looking for source scripts`.

## Quick test (optional)

`TheTestScript\scripts\HelloSource.net.cs` is a tiny **test script** that only shows the mod is working.

1. Copy it into the game's main **`scripts`** folder, the one next to `GTAIV.exe` (not `IVSDKDotNet\scripts`).
2. Start the game. A few seconds after you're in control, this shows on screen:
   ```
   HelloSource.net.cs: compiled from source and running
   ```
3. Delete `HelloSource.net.cs` from `scripts` afterwards. Its compiled file is removed automatically on the next start.

## Using it

Put source scripts where ScriptHookDotNet 1.7.1.9 wanted them, in the game's **`scripts`** folder, then start the game:

```
GTA IV\
  scripts\
    ChopShop.cs                 <- the mod's source script
    ChopShop.compiled.net.dll   <- made automatically; IV-SDK .NET loads this
```

- **New or changed scripts** are compiled at game start and load on that same start.
- **Unchanged scripts** aren't compiled again, so later starts stay fast.
- **To remove a mod**, delete its `.cs` / `.vb` file. Its `.compiled.net.dll` is deleted on the next start.
- **Edited a script?** Restart the game. Scripts are only compiled when the game starts.
- In `IVSDKDotNet\scripts\`, only files named `*.net.cs` / `*.net.vb` are compiled, because that folder also holds IV-SDK .NET's own files.

A script that needs another library can add a line like `//#reference SomeLibrary.dll` (VB: `'#reference SomeLibrary.dll`).

## If a script doesn't load

Check **`IVSDKDotNet\IVSDKScriptCompiler.log`** or the F4 console. Compile errors are listed there with file, line and message. A script with errors just doesn't load; the game and your other mods carry on.

- **Most common cause:** the script uses newer C# syntax. The compiler built into Windows understands C# 5 / VB 11. Old ScriptHookDotNet scripts are fine, but things like `$"..."` strings or `?.` won't compile.
- **Harmless:** IV-SDK .NET's own log shows two yellow lines for each source script, such as *"The file 'ChopShop.cs' is not a IV-SDK .NET or ScriptHookDotNet script file."* IV-SDK .NET looks at the source file too, can't load it itself, and skips it. The compiled copy is what loads.

## Antivirus notes

- At game start this mod runs the C# / VB compiler that comes with Windows (`csc.exe` / `vbc.exe` from .NET Framework 4). That's how .NET's built-in compiling works, and ScriptHookDotNet 1.7.1.9 did the same. It also writes `.compiled.net.dll` files next to your source scripts.
- It only reads and writes in `scripts\`, `IVSDKDotNet\scripts\` and its log. It has no network access and doesn't touch the registry or the game's memory.
- The release dll has been scanned with Microsoft Defender. If your antivirus flags it anyway, you can build it yourself from the source on GitHub with the included `build.bat`, and please report the false positive.

## Uninstall

Delete `IVSDKDotNet\scripts\IVSDKScriptCompiler.ivsdk.dll`, any `*.compiled.net.dll` files it made, and `IVSDKDotNet\IVSDKScriptCompiler.log`.

## Credits and license

By bassisthip63-ui, written with Claude (Anthropic). MIT License, see `LICENSE`.

IV-SDK .NET is by ItsClonkAndre. This mod isn't part of it and isn't endorsed by its author. GTA IV is a trademark of Rockstar Games / Take-Two Interactive; this mod isn't affiliated with them.
